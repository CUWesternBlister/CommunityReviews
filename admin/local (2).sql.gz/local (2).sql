-- Adminer 4.8.1 MySQL 8.0.16 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `wp_bcr_brands`;
CREATE TABLE `wp_bcr_brands` (
  `brandID` int(9) NOT NULL AUTO_INCREMENT,
  `brandName` varchar(512) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`brandID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_bcr_brands` (`brandID`, `brandName`) VALUES
(1,	'4FRNT'),
(2,	'Blizzard'),
(3,	'Deuter'),
(4,	'DPS'),
(5,	'Dynafit'),
(6,	'Elan'),
(7,	'Fischer'),
(8,	'Flylow'),
(9,	'Folsom'),
(10,	'Glade'),
(11,	'HEAD'),
(12,	'Icelantic'),
(13,	'K2'),
(14,	'Line'),
(15,	'Majesty'),
(16,	'Meier'),
(17,	'Moment'),
(18,	'Ortovox'),
(19,	'Peak Skis'),
(20,	'Pomoca'),
(21,	'Renoun'),
(22,	'Rossignol'),
(23,	'Salomon'),
(24,	'Scott'),
(25,	'THERM-IC'),
(26,	'Wagner'),
(27,	'WNDR Alpine'),
(28,	'ZipFit');

DROP TABLE IF EXISTS `wp_bcr_categories`;
CREATE TABLE `wp_bcr_categories` (
  `categoryID` int(9) NOT NULL AUTO_INCREMENT,
  `parentID` int(9) DEFAULT NULL,
  `categoryName` varchar(512) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`categoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_bcr_categories` (`categoryID`, `parentID`, `categoryName`) VALUES
(1,	0,	'Ski'),
(2,	1,	'Ski Boots'),
(3,	0,	'Apparel'),
(4,	1,	'Skis'),
(5,	1,	'Climbing Skins'),
(6,	0,	'Snowboard'),
(7,	6,	'Snowboards');

DROP TABLE IF EXISTS `wp_bcr_products`;
CREATE TABLE `wp_bcr_products` (
  `productID` int(9) NOT NULL AUTO_INCREMENT,
  `categoryID` int(9) NOT NULL,
  `brandID` int(9) NOT NULL,
  `productName` varchar(512) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`productID`),
  KEY `categoryID` (`categoryID`),
  KEY `brandID` (`brandID`),
  CONSTRAINT `wp_bcr_products_ibfk_1` FOREIGN KEY (`categoryID`) REFERENCES `wp_bcr_categories` (`categoryID`),
  CONSTRAINT `wp_bcr_products_ibfk_2` FOREIGN KEY (`brandID`) REFERENCES `wp_bcr_brands` (`brandID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


DROP TABLE IF EXISTS `wp_bcr_questions`;
CREATE TABLE `wp_bcr_questions` (
  `questionID` int(9) NOT NULL AUTO_INCREMENT,
  `questionContent` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `questionDisplayContent` varchar(512) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`questionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_bcr_questions` (`questionID`, `questionContent`, `questionDisplayContent`) VALUES
(1,	'Brand Tested',	''),
(2,	'Product tested',	''),
(3,	'Length Tested',	''),
(4,	'Where did you test it?',	''),
(5,	'What type of terrain did you ski?',	''),
(6,	'What type of conditions did you ski in?',	''),
(7,	'How did you feel about the Maneuverability of this ski?',	''),
(8,	'The Stability of the ski: (check all that apply)',	''),
(9,	'How did you feel about the Stability of this ski?',	''),
(10,	'How demanding or punishing did you find the ski to be?',	''),
(11,	'Ride quality / suspension. This ski felt: ',	''),
(12,	'The ski felt comfortable to me on / in (check all that apply): ',	''),
(13,	'How would you describe the fun-factor of this ski?',	''),
(14,	'Did you feel like you were on the correct length of this ski?',	''),
(15,	'What type of skier do you imagine will get along best with this ski? (check all that apply)',	''),
(16,	'How much do you like the looks of the product?',	''),
(17,	'Please feel free to elaborate:',	''),
(18,	'How likely are you to either buy or recommend this product?',	''),
(19,	'Please feel free to elaborate:',	''),
(20,	'Are there similar products you\'ve skied that you clearly prefer? If so, which products and what about them makes you prefer them?',	''),
(21,	'Anything else you\'d like to add?',	''),
(22,	'Ski Boot Size',	''),
(23,	'Boot fit',	''),
(24,	'Please describe the ski boot\'s performance:',	''),
(25,	'How did the boot stance feel?',	''),
(26,	'How did the flex pattern feel?',	''),
(27,	'How did the weight of the boot feel?',	''),
(28,	'Difficulty of putting on and taking off boots. 1 - easy. 10 - difficult.',	''),
(29,	'Touring Boots Buckles',	''),
(30,	'Touring Boots Walk Mechanism',	''),
(31,	'Touring Boot power straps ',	''),
(32,	'Touring Boots/ Boots with walk mode – Walking:',	''),
(33,	'Is this a Touring Boot?',	''),
(34,	'Fit of Apparel',	''),
(35,	'How did the fabric feel? 1 -terrible. 10 - excellent.',	''),
(36,	'Apparel Weather Resistance ',	''),
(37,	'Apparel Breathability',	''),
(38,	'Apparel Warmth',	''),
(39,	'Do you tend to run cold or hot? ',	''),
(40,	'Features of Apparel',	''),
(41,	'Looks/Aesthetics of Apparel. 1 - unattractive. 10 - attractive.',	''),
(42,	'Stability - How would you rate this board\'s stability and composure at speed?',	'Stability Rating'),
(43,	'Maneuverability - How would you rate the maneuverability of this board? (i.e., how easy was it to turn/pivot)',	'Maneuverability Rating'),
(44,	'Forgiveness - How would you rate the snowboard\'s forgiveness when you made a mistake/rode with poor technique?',	'Forgiveness Rating'),
(45,	'Suspension - How would you rate this board\'s suspension? (i.e. how smooth/damp/plush it felt in firm and/or variable conditions)',	'Suspension Rating'),
(46,	'Fun Factor - In general, how would you rate the fun-factor of the board? (i.e. how much you enjoyed it over all)',	'Fun Factor Rating '),
(47,	'Ideal Terrain - In which terrain did you enjoy your time on this board?',	'Ideal Terrain'),
(48,	'Length - How did you feel about the length of this board?',	'Length'),
(49,	'What type(s) of rider do you imagine will get along best with this board?',	'What type(s) of people do you imagine will get along best with this snowboard?'),
(50,	'How likely are you to either buy or recommend this product?',	'How likely are you to either buy or recommend this product?'),
(51,	'Are there similar products you\'ve ridden that you clearly prefer? If so, why?',	'Similar products you\'ve ridden that you clearly prefer, and why?'),
(52,	'Please elaborate on anything else you\'d like to say about this board, feel free to go into detail!',	'Open ended response: '),
(53,	'What type of conditions did you use it in?',	'Test Conditions'),
(54,	'Glide - How would you rate the glide of this skin?',	'Glide'),
(55,	'Grip - How would you rate the grip of this skin?',	'Grip'),
(56,	'Packability - How would you rate the packability of this skin?',	'Packability'),
(57,	'What type(s) of people do you imagine will get along best with this product?',	'What type(s) of people do you imagine will get along best with this product?'),
(58,	'How likely are you to either buy or recommend this product?',	'How likely are you to either buy or recommend this product?'),
(59,	'Are there similar products you\'ve tried that you clearly prefer? If so why?',	'Similar products you\'ve ridden that you clearly prefer, and why?'),
(60,	'Please elaborate on anything else you\'d like to say about this product. Feel free to go into detail.',	'Open ended response: '),
(100,	'Name ------ test form',	''),
(101,	'Email ----- test form',	''),
(102,	'message --- test form',	''),
(103,	'Brand Tested Fluent Forms',	''),
(104,	'Product Tested Fluent Forms',	''),
(105,	'Where did you test it? Fluent Forms',	''),
(106,	'Did you feel you were on the correct length of this ski? Fluent Forms',	''),
(107,	'Please feel free to elaborate: Fluent Forms',	''),
(108,	'How good are you at Test Sport?',	''),
(109,	'How do you like Test Product?',	''),
(110,	'Would you recommend Test Product?',	''),
(111,	'Any final thoughts?',	'');

DROP TABLE IF EXISTS `wp_bcr_review_forms`;
CREATE TABLE `wp_bcr_review_forms` (
  `reviewFormID` int(9) NOT NULL AUTO_INCREMENT,
  `reviewFormName` varchar(512) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `categoryID` int(9) NOT NULL,
  PRIMARY KEY (`reviewFormID`),
  KEY `categoryID` (`categoryID`),
  CONSTRAINT `wp_bcr_review_forms_ibfk_1` FOREIGN KEY (`categoryID`) REFERENCES `wp_bcr_categories` (`categoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_bcr_review_forms` (`reviewFormID`, `reviewFormName`, `categoryID`) VALUES
(5,	'Summit_Ski_Boot_Review_Form',	2),
(6,	'Summit_Apparel_Form',	3),
(8,	'Ski Review Form',	4);

DROP TABLE IF EXISTS `wp_bcr_reviews`;
CREATE TABLE `wp_bcr_reviews` (
  `reviewID` int(9) NOT NULL AUTO_INCREMENT,
  `userID` int(9) NOT NULL,
  `reviewFormID` int(9) NOT NULL,
  PRIMARY KEY (`reviewID`),
  KEY `reviewFormID` (`reviewFormID`),
  KEY `userID` (`userID`),
  CONSTRAINT `wp_bcr_reviews_ibfk_1` FOREIGN KEY (`reviewFormID`) REFERENCES `wp_bcr_review_forms` (`reviewFormID`),
  CONSTRAINT `wp_bcr_reviews_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `wp_bcr_users` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


DROP TABLE IF EXISTS `wp_bcr_reviews_answers`;
CREATE TABLE `wp_bcr_reviews_answers` (
  `reviewID` int(9) NOT NULL,
  `answerID` int(9) NOT NULL,
  PRIMARY KEY (`reviewID`,`answerID`),
  KEY `answerID` (`answerID`),
  CONSTRAINT `wp_bcr_reviews_answers_ibfk_1` FOREIGN KEY (`reviewID`) REFERENCES `wp_bcr_reviews` (`reviewID`),
  CONSTRAINT `wp_bcr_reviews_answers_ibfk_2` FOREIGN KEY (`answerID`) REFERENCES `wp_bcr_answers` (`answerID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


-- 2023-01-31 05:14:37
