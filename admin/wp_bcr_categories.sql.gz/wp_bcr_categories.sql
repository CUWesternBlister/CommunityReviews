-- Adminer 4.8.1 MySQL 8.0.16 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

INSERT INTO `wp_bcr_categories` (`categoryID`, `parentID`, `categoryName`) VALUES
(1,	0,	'Ski'),
(2,	1,	'Ski Boots'),
(3,	0,	'Apparel'),
(4,	1,	'Skis'),
(5,	1,	'Climbing Skins'),
(6,	0,	'Snowboard'),
(7,	6,	'Snowboards');

-- 2023-02-09 17:35:50
