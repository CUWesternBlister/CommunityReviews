-- Adminer 4.8.1 MySQL 8.0.16 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

INSERT INTO `wp_bcr_brands` (`brandID`, `brandName`) VALUES
(1,	'4FRNT'),
(2,	'Blizzard'),
(3,	'Deuter'),
(4,	'DPS'),
(5,	'Dynafit'),
(6,	'Elan'),
(7,	'Fischer'),
(8,	'Flylow'),
(9,	'Folsom'),
(10,	'Glade'),
(11,	'HEAD'),
(12,	'Icelantic'),
(13,	'K2'),
(14,	'Line'),
(15,	'Majesty'),
(16,	'Meier'),
(17,	'Moment'),
(18,	'Ortovox'),
(19,	'Peak Skis'),
(20,	'Pomoca'),
(21,	'Renoun'),
(22,	'Rossignol'),
(23,	'Salomon'),
(24,	'Scott'),
(25,	'THERM-IC'),
(26,	'Wagner'),
(27,	'WNDR Alpine'),
(28,	'ZipFit'),
(29,	'Dynastar');

-- 2023-04-07 22:06:54
