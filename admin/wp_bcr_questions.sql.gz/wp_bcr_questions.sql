-- Adminer 4.8.1 MySQL 8.0.16 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

INSERT INTO `wp_bcr_questions` (`questionID`, `questionContent`, `questionDisplayContent`, `questionType`) VALUES
(1,	'Brand Tested',	'',	'title'),
(2,	'Product tested',	'',	'title'),
(3,	'Length Tested',	'',	'title'),
(4,	'Where did you test it?',	'Inbounds or Backcountry',	'testingConditions'),
(5,	'What type of terrain did you ski?',	'Test Terrain',	'testingConditions'),
(6,	'What type of conditions did you ski in?',	'Test Conditions',	'testingConditions'),
(7,	'How did you feel about the Maneuverability of this ski?',	'Maneuverability Rating',	'multipleChoice'),
(8,	'The Stability of the ski: (check all that apply)',	'Stability Rating',	'multipleChoice'),
(9,	'What year of model did you test?',	'Model Year',	'title'),
(10,	'How would you rate how forgiving this ski felt when you made a mistake / skied with poor technique?',	'Forgiveness Rating',	'multipleChoice'),
(11,	'How would you rate this ski’s suspension? (i.e., how smooth / damp / plush / smooth it felt in firm and/or variable conditions) ',	'Supension Rating',	'multipleChoice'),
(13,	'How would you describe the fun-factor of this ski?',	'Fun Factor Rating',	'multipleChoice'),
(14,	'Did you feel like you were on the correct length of this ski?',	'Length',	'multipleChoice'),
(15,	'In which terrain did you enjoy your time on this ski?',	'Ideal Terrain',	'multipleChoice'),
(17,	'Please feel free to elaborate:',	'Elaboration on Ideal Terrain',	'testimony'),
(18,	'How likely are you to either buy or recommend this product?',	'How likely to buy or recommend',	'multipleChoice'),
(19,	'Please feel free to elaborate:',	'Elaboration',	'testimony'),
(20,	'Are there similar products you\'ve skied that you clearly prefer? If so, which products and what about them makes you prefer them?',	'Similar Products you prefer? If so, why? ',	'testimony'),
(21,	'Anything else you\'d like to add?',	'Personal Comment',	'testimony'),
(22,	'Ski Boot Size',	'Ski Boot Size',	'title'),
(23,	'Boot fit',	'Boot fit',	'multipleChoice'),
(25,	'How would you rate this boot’s suspension? (i.e., how smooth / damp / plush / smooth it felt in firm and/or variable conditions)',	'Suspension Rating',	'multipleChoice'),
(26,	'How do you rate this boot\'s flex pattern?',	'Stiffness / Flex Pattern',	'multipleChoice'),
(27,	'How would you rate how well this boot walks / skins uphill?',	'Uphill Mobility',	'multipleChoice'),
(28,	'How would rate the breathability of the boot? ',	'Breathability',	'multipleChoice'),
(33,	'What type of Conditions did you test this apparel in? ',	'Conditions',	'multipleChoice'),
(34,	'Fit of Apparel',	'Apparel Fit',	'multipleChoice'),
(35,	'How would you rate the overall comfort of this product?',	'Overall Comfort',	'multipleChoice'),
(36,	'Apparel Weather Resistance ',	'Weather Protection',	'multipleChoice'),
(37,	'How would you rate the Breathability of this apparel item? ',	'Breathability',	'multipleChoice'),
(38,	'What type(s) of people do you imagine will get along best with this product?',	'What type(s) of people do you imagine will get along best with this product?',	'testimony'),
(42,	'Stability - How would you rate this board\'s stability and composure at speed?',	'Stability Rating',	'multipleChoice'),
(43,	'Maneuverability - How would you rate the maneuverability of this board? (i.e., how easy was it to turn/pivot)',	'Maneuverability Rating',	'multipleChoice'),
(44,	'Forgiveness - How would you rate the snowboard\'s forgiveness when you made a mistake/rode with poor technique?',	'Forgiveness Rating',	'multipleChoice'),
(45,	'Suspension - How would you rate this board\'s suspension? (i.e. how smooth/damp/plush it felt in firm and/or variable conditions)',	'Suspension Rating',	'multipleChoice'),
(46,	'Fun Factor - In general, how would you rate the fun-factor of the board? (i.e. how much you enjoyed it over all)',	'Fun Factor Rating ',	'multipleChoice'),
(47,	'Ideal Terrain - In which terrain did you enjoy your time on this board?',	'Ideal Terrain',	'multipleChoice'),
(48,	'Length - How did you feel about the length of this board?',	'Length',	'multipleChoice'),
(49,	'What type(s) of rider do you imagine will get along best with this board?',	'What type(s) of people do you imagine will get along best with this snowboard?',	'testimony'),
(50,	'How likely are you to either buy or recommend this product?',	'How likely are you to either buy or recommend this product?',	'multipleChoice'),
(51,	'Are there similar products you\'ve ridden that you clearly prefer? If so, why?',	'Similar products you\'ve ridden that you clearly prefer, and why?',	'testimony'),
(52,	'Please elaborate on anything else you\'d like to say about this board, feel free to go into detail!',	'Open ended response: ',	'testimony'),
(53,	'What type of conditions did you use it in?',	'Test Conditions',	'testingConditions'),
(54,	'Glide - How would you rate the glide of this skin?',	'Glide',	'multipleChoice'),
(55,	'Grip - How would you rate the grip of this skin?',	'Grip',	'multipleChoice'),
(56,	'Packability - How would you rate the packability of this skin?',	'Packability',	'multipleChoice'),
(57,	'What type(s) of people do you imagine will get along best with this product?',	'What type(s) of people do you imagine will get along best with this product?',	'testimony'),
(58,	'How likely are you to either buy or recommend this product?',	'How likely are you to either buy or recommend this product?',	'multipleChoice'),
(59,	'Are there similar products you\'ve tried that you clearly prefer? If so why?',	'Similar products you\'ve ridden that you clearly prefer, and why?',	'testimony'),
(60,	'Please elaborate on anything else you\'d like to say about this product. Feel free to go into detail.',	'Open ended response: ',	'testimony'),
(61,	'How would you rate the fit of this backpack?',	'Fit',	'multipleChoice'),
(62,	'Did you feel that the backpack had adequate pockeks/storage? Why or Why not?',	'Did you feel that the backpack had adequate pockeks/storage? ',	'testimony');

-- 2023-02-09 17:35:57
